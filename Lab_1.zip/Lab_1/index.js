Timeout(() => {
  console.log("Test JS");
}, 4000);
